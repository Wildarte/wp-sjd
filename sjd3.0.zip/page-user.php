<?php
//Silence is good