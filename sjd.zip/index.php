<?php get_header(); ?>

    <main>
    
        <h1>Index</h1>

    </main>

<?php get_footer(); ?>